import { Home } from "@/lib/pages/home";

export default Home;
