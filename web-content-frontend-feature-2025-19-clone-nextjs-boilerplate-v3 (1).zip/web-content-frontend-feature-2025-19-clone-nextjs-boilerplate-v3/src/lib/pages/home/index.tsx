'use client'

import { Count } from "@/lib/components/count";
import { useEffect, useState } from "react"

export const Home = () => {
    const [data, setData] = useState<any>();

    const fetchData = async () =>{
      
        const result = await fetch(`/api/example`)
        const data = await result.json()
        setData(data.data)
    }
        
    useEffect(()=>{    
        fetchData()
    },[])

  return (
    <div>
        <Count updateItem={data}/>
    </div>
  )
}
